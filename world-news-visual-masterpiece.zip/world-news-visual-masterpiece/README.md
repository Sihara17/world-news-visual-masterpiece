# World News Visual Masterpiece

A deterministic, offline make.fun entry for **“Sum up 13 November's world news in one image.”**

## Contents

- `main.py` — Python 3.13 standard-library entrypoint. Copies the fixed image to `$MAKEFUN_OUTPUT_DIR/entry.png` (default: `/output/entry.png`).
- `entry.png` — the final 1024 × 1024 editorial image. The file uses JPEG encoding despite the required `entry.png` filename; the contest brief says the grader identifies the format by its first bytes and keeps this filename either way.
- `assets/source-notes.md` — editorial scope and source links.
- `LICENSE` — MIT License.

## Run locally

```sh
mkdir -p out
MAKEFUN_OUTPUT_DIR=out python3 main.py
file out/entry.png
```

The program uses only the Python standard library, makes no network requests, and copies identical bytes on every run.

## Important submission checklist

1. Create a **new public GitHub repository** under your own account after the competition opened.
2. Keep `main.py` and `entry.png` at the repository root.
3. Upload the genuine AI coding-agent session transcript(s) that built/revised the entry. **No transcript is included in this ZIP**; do not fabricate one. Follow the contest's current transcript/bundle instructions and ensure the logs satisfy its timestamp, usage, authored-line, revision, and turn requirements.
4. Test the entry twice and compare output hashes before submitting.
5. Submit the repository commit and the authentic transcript bundle through make.fun.

This package is a starter source bundle, not a guarantee of contest eligibility or a prize. Review the live contest rules before submission.
