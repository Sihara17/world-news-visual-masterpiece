# Editorial source notes — Friday, 13 November 2026

The image is a symbolic editorial montage, not a literal photograph. Its motifs were selected to evoke several major stories reported on the date:

- **Ukraine / diplomacy and war:** reports of a major Ukrainian drone attack on Russia and US-mediated Russia–Ukraine talks in Abu Dhabi; European leaders also sought a role in peace talks.
- **Middle East / maritime security:** reporting on threats to shipping around the Strait of Hormuz amid the Iran conflict.
- **Gaza / humanitarian emergency:** UN reporting called for urgent winter supplies after deadly rainfall and flooding affected displaced people.
- **Climate:** COP31 was underway in Antalya, with disputes over climate finance, adaptation and energy priorities.
- **Digital infrastructure:** reports described a Microsoft service outage affecting users and services, including contingency measures in England's health service.

These are represented with broad visual symbols (war-damaged city, tanker, flooded aid camp, climate summit and connected digital network). The image intentionally avoids small headlines, casualty figures, or detailed labels that could become illegible or imply unsupported precision.

## Sources consulted

- Anadolu Agency, “Morning Briefing: Nov. 13” (13 Nov 2026): https://www.aa.com.tr/en/world/morning-briefing-nov-13/4123624
- UN News / Global Issues November 2026 digest, dated 13 Nov 2026 (COP31, Hormuz, Gaza winter supplies, DRC Ebola): https://www.globalissues.org/news/2026/11
- Reuters, “Conflicting demands at COP31” (13 Nov 2026): https://www.reuters.com/sustainability/conflicting-demands-cop31-2026-11-13/
- Associated Press coverage index for 13 Nov 2026 (Ukraine drone attack and Abu Dhabi talks): https://www.washingtonpost.com/world/wires/?page=1
- Arab News world wire archive (13 Nov 2026; includes Microsoft outage and other international reports): https://www.arabnews.com/world?page=2438&quicktabs_stat2=0&service=rss

The contest judge sees only the image, not this note. The note documents the editorial intent and source trail for the entrant.
